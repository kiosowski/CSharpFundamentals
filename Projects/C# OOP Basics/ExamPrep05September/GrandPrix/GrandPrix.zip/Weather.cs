﻿public enum Weather
{
    Sunny,
    Foggy,
    Rainy
}