﻿using System;
using System.Collections.Generic;
using System.Text;

public struct BakingTechnique
{
    public const double Crispy = 0.9;
    public const double Chewy = 1.1;
    public const double Homemade = 1.0;
}

