﻿using System;
using System.Collections.Generic;
using System.Text;


public class FlourType
{
    public const double White = 1.5;
    public const double Wholegrain = 1.0;
}

