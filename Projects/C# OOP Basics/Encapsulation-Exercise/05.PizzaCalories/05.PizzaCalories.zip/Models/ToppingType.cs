﻿using System;
using System.Collections.Generic;
using System.Text;


public struct ToppingType
{
    public const double Meat = 1.2;
    public const double Veggies = 0.8;
    public const double Cheese = 1.1;
    public const double Sauce = 0.9;
}

