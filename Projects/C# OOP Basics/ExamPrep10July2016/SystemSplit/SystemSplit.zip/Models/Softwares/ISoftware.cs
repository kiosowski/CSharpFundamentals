﻿public interface ISoftware
{
    string Name { get; }
    int CapacityConsumption { get; }
    int MemoryConsumption { get; }
}