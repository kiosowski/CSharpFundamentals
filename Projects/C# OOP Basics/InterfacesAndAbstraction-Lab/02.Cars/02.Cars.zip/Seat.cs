﻿using System;
using System.Collections.Generic;
using System.Text;

public class Seat : Audi
{
    public Seat(string model,string color) : base(model, color)
    {

    }
}

