﻿using System;

namespace _03.Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
