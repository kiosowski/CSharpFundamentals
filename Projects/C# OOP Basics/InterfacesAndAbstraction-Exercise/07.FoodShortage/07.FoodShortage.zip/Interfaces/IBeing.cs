﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBeing
{
    string Id { get; }
}

