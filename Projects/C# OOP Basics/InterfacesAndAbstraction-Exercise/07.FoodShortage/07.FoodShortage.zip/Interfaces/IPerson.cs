﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IPerson : INamable,IBuyer,IAging
{

}

