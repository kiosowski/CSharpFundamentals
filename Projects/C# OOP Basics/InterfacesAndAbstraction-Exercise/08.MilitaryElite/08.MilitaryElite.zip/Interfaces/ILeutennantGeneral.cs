﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ILeutennantGeneral
{
    IReadOnlyList<Private> Privates { get; }
}

