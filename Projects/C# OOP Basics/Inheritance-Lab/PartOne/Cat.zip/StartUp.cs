﻿using System;

namespace PartOne
{
    class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
