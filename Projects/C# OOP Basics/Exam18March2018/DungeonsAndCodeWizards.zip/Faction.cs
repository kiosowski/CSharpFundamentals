﻿namespace DungeonsAndCodeWizards
{
    public enum Faction
    {
        CSharp,
        Java
    }
}