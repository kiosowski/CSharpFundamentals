﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Wariors
{
    public interface IHealable
    {
         void Heal(Character character);
    }
}
