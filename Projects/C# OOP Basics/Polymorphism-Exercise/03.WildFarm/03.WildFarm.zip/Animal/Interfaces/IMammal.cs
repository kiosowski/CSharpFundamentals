﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMammal:IAnimal
{
    string LivingRegion { get; set; }
}