﻿public interface IFood
{
    int Quantity { get; set; }
}