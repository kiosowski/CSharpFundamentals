﻿using System;
using System.Collections.Generic;
using System.Text;

public class Car:Vehicle
{
    public Car(double fuelAmount,double fuelConsumption, double airConditioningConsumption)
        : base(fuelAmount, fuelConsumption, airConditioningConsumption)
    {

    }
}
