﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Harvester
{
    private string id;
    private double oreOutput;
    private double energyRequirement;
    public Harvester(string id,double oreOutput,double energyRequirement)
    {
        this.Id = id;
        this.OreOutput = oreOutput;
        this.EnergyRequirement = energyRequirement;
    }
    public double EnergyRequirement
    {
        get
        {
            return energyRequirement;
        }
        set
        {
            if (value < 0 || value > 20000)
            {
                throw new ArgumentException("EnergyRequirement cannot be less than 0 and more than 20000");
            }
            energyRequirement = value;
        }
    }

    public double OreOutput
    {
        get
        {
            return oreOutput;
        }
        set
        {
            if (value < 0 || value > 20000)
            {
                throw new ArgumentException("OreOutput cannot be less than 0 and more than 20000");
            }
            oreOutput = value;
        }
    }

    public string Id
    {
        get { return id; }
        set { id = value; }
    }

}

