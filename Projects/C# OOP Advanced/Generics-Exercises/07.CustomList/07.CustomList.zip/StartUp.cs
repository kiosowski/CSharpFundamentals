﻿using System;

namespace _07.CustomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.ExecuteCommands();
        }
    }
}
