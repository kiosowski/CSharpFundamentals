﻿using System;

namespace _03.GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
