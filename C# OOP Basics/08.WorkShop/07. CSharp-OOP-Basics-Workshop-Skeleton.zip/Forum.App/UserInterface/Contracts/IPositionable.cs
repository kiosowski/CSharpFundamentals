﻿namespace Forum.App.UserInterface.Contracts
{
    public interface IPositionable
    {
        Position Position { get; }
    }
}
