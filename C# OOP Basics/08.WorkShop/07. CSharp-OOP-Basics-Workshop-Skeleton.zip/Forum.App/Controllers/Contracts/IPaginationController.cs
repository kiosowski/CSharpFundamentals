﻿namespace Forum.App.Services.Contracts
{
    interface IPaginationController
    {
        int CurrentPage { get; set; }
    }
}
